package devesh.ephrine.backup.sms;

import java.util.ArrayList;
import java.util.HashMap;

public class AppData {
    public static int a;
    public static int b;
    public HashMap<String, ArrayList<HashMap<String, String>>> iThread = new HashMap<>();

}
